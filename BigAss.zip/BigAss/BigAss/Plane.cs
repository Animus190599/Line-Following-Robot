﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigAss
{
    class Plane
    {
        public float range
        {
            get;
            set;
        }
        public float speed
        {
            get;
            set;
        }
        public float takeOff
        {
            get;
            set;

        }
        public float landing
        {
            get;
            set;
        }
        public float fuel
        {
            get;
            set;
        }
        public Plane(float range, float speed, float takeOff, float landing, float fuel)
        {
            this.range = range;
            this.speed = speed;
            this.takeOff = takeOff;
            this.landing = landing;
            this.fuel = fuel;
        }
        public TimeSpan Convert(float value, string type)
        {

            if (type == "hh") {
                return TimeSpan.Parse(string.Format("{0}:0:0", Math.Round(value)));
            }
            else if (type == "mm")
            {
                return TimeSpan.Parse(string.Format("0:{0}:0", Math.Round(value)));
            }
            else
            {
                return TimeSpan.Parse(string.Format("0:0:{0}", Math.Round(value)));
            }
            

            
        }
    }
}
