﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigAss
{
    class Tour
    {
        public List<Station> station
        {
            get;
            set;
        }
        public Plane plane
        {
            get;
            set;
        }
        public Tour(List<Station> station, Plane plane)
        {
            this.station = station;
            this.plane = plane;
        }
        //public void AddStation(Station s)
        //{
        //    station.Add(s);
        //}
        public float TourLength()
        {
            float total = 0;
            for (int i = 0; i < this.station.Count - 1; ++i)
            {
                total += station[i].Distance(station[i + 1]);
            }
            return total;
        }
        public void Swap(int oldID, int newID)
        {
            Station curStation = station[oldID];
            station.RemoveAt(oldID);
            station.Insert(newID, curStation);
        }
        public string PathTime(int i)
        {
            int addTime = (int)(Math.Round(this.station[i].Distance(this.station[i+1]) / plane.speed * 60.0 + plane.takeOff + plane.landing));
            int hour = 0;
            if (addTime > 60)
            {
                hour = (int)(addTime / 60);
                addTime %= 60;
            }
            return string.Format("{0}:{1}:0",hour, addTime);
        }
        
    }
}
