﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigAss
{
    class Station
    {
        public string Name
        {
            get;
            set;
        }
        public float x
        {
            get;
            set;
        }
        public float y
        {
            get;
            set;
        }

        public Station(string Name, float x, float y)
        {
            this.Name = Name;
            this.x = x;
            this.y = y;
        }
        public float Distance(Station s)
        {
            return (float)Math.Sqrt(Math.Pow((x - s.x), 2) + Math.Pow((y - s.y), 2));
        }
        public bool Equals(Station s)
        {
            if (this.Name == s.Name && this.x == s.x && this.y == s.y)
            {
                return true;
            }
            return false;
        }
    }
}
