using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Text;
using System.Linq;
using System.IO;

namespace BigAss
{
    class Program
    {
        static List<Station> stations = new List<Station>();
        static Plane plane;
        static TimeSpan curTime;

        static void Main(string[] args)
        {
            string rdPath = "D:/Animus_files/Documents/CAB201/"+ args[0];
            string planePath = "D:/Animus_files/Documents/CAB201/"+args[1];
            try
            {
                curTime = TimeSpan.Parse(args[2]);
            }
            catch (FormatException)
            {
                Console.WriteLine("Unable to parse '{0}'", args[2]);
            }
            catch (OverflowException)
            {
                Console.WriteLine("'{0}' is outside the range of a TimeSpan.", args[2]);
            }
           
            Program.ReadStationsFromFile(rdPath);
            Program.ReadPlaneSpecFromFile(planePath);
            ////Level 1--------------------------------------------------------
            //Tour tour = new Tour(SimpleHeuristic(stations), plane);
            ////Level 2-------------------------------------------------------
            //tour = ImprovedHeuristic(tour);
            //Level 3 --------------------------------------------------------
            Tour tour = new Tour(stations, plane);
            tour = ExhaustiveSearch(tour);
            //for (int i = 0; i <=stations.Count; ++i)
            //{
            //    Console.WriteLine("{0}", tour.station[i].Name);
            //}
            //if (args[3] == "-o")
            //{
            //    string wrPath = "D:/ Animus_files / Documents / CAB201 /" + args[4];
            //    Program.WriteMessageToFile(tour, wrPath);
            //}
            string wrPath = "D:/Animus_files/Documents/CAB201/write.txt";
            Program.WriteMessageToFile(tour, wrPath);



            Console.ReadLine();
        }

        public static void ReadStationsFromFile(string rdPath)
        {

            try
            {
                using (StreamReader mySR = new StreamReader(new FileStream(rdPath, FileMode.Open, FileAccess.Read)))
                {
                    while (!mySR.EndOfStream)
                    {
                        string[] splitLine = mySR.ReadLine().Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                        Console.WriteLine("{0} ({1},{2})", splitLine[0], float.Parse(splitLine[1]), float.Parse(splitLine[2]));
                        Program.stations.Add(new Station(splitLine[0], float.Parse(splitLine[1]), float.Parse(splitLine[2])));
                    }
                }
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void ReadPlaneSpecFromFile(string planePath)
        {

            try
            {
                using (StreamReader mySR = new StreamReader(new FileStream(planePath, FileMode.Open, FileAccess.Read)))
                {
                    while (!mySR.EndOfStream)
                    {
                        string[] splitLine = mySR.ReadLine().Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                        Console.WriteLine("{0} {1} {2} {3} {4}", float.Parse(splitLine[0]), float.Parse(splitLine[1]), float.Parse(splitLine[2]), float.Parse(splitLine[3]), float.Parse(splitLine[4]));
                        plane = new Plane(float.Parse(splitLine[0]), float.Parse(splitLine[1]), float.Parse(splitLine[2]), float.Parse(splitLine[3]), float.Parse(splitLine[4]));
                    }
                }
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
        }

       

        public static void WriteMessageToFile(Tour tour, string wrPath)
        {
            using (StreamWriter mySW = new StreamWriter(new FileStream(wrPath, FileMode.Create, FileAccess.ReadWrite)))
            {
                var watch = System.Diagnostics.Stopwatch.StartNew();
                List<string> myList = new List<string>();
                TimeSpan totalTime = new TimeSpan(0, 0, 0);
                TimeSpan operationTime = plane.Convert(plane.range, "hh");
                TimeSpan fuelTime = plane.Convert(plane.fuel, "mm");
                float totalDist = 0;
                string time1, time2;

               
                for (int i = 0; i < stations.Count-1; ++i)
                {
                  
                    
                    totalTime += TimeSpan.Parse(tour.PathTime(i));


                    if (TimeSpan.Compare(totalTime, operationTime) > 0)
                    {
                        curTime += fuelTime;
                        operationTime += operationTime;
                        totalTime += fuelTime;
                        myList.Add(string.Format("***refuel {0} minutes ***", fuelTime.ToString().Split(':')[1]));
                    }
                    time1 = curTime.Hours.ToString("D2") + ":" + curTime.Minutes.ToString("D2");
                    curTime += TimeSpan.Parse(tour.PathTime(i));
                    time2 = curTime.Hours.ToString("D2") + ":" + curTime.Minutes.ToString("D2");

                    myList.Add(string.Format("{0}    \t->\t{1}\t{2}\t{3}", tour.station[i].Name, tour.station[i+1].Name, time1, time2));
                    totalDist += tour.station[i].Distance(tour.station[i + 1]);
                }
                watch.Stop();
                mySW.WriteLine("Optimising tour length: Level 3...Elapsed time: {0} milliseconds",watch.ElapsedMilliseconds);
                mySW.WriteLine("Tour time: {0} hours {1} minutes", totalTime.ToString().Split(':')[0], totalTime.ToString().Split(':')[1]);
                mySW.WriteLine("Tour length: {0}", totalDist);
                foreach (string var in myList)
                {
                    mySW.WriteLine(var);
                }
                mySW.Close();
            }


        }



        // LEVEL 1 - ###################################################################################################################################################################
        public static List<Station> SimpleHeuristic(List<Station> stations)
        {
            List<Station> stationSimple = new List<Station>();
            stationSimple.Add(stations[0]);
            stationSimple.Add(stations[0]);
            float minLength = 100000, curLength=0;
            int curMinPos = 0;
            for (int i = 1; i < stations.Count; ++i)
            {
                minLength = 100000;
                curMinPos = 0;
                for (int j = 0; j <i; ++j)
                {

                    //if (j == stationSimple.Count - 1)
                    //{
                    //    curLength = stations[i].Distance(stationSimple[j]);
                    //}

                    //else
                    //{
                        curLength = stations[i].Distance(stationSimple[j])  + stations[i].Distance(stationSimple[j + 1]) - stations[j].Distance(stations[j + 1]);
                    //}

                    //if (j == 0)
                    //{
                    //    minLength = curLength;
                    //    curMinPos = j + 1;
                    //}
                    if (curLength < minLength)
                    {
                        minLength = curLength;
                        curMinPos = j + 1;
                    }
                }
                stationSimple.Insert(curMinPos, stations[i]);
            }
            //stationSimple.Add(stations[0]);
            return stationSimple;
        }
        //LEVEL 2 - ######################################################################################################################################################
        public static Tour ImprovedHeuristic(Tour tour)
        {
            float minDist = tour.TourLength();
            float newDist = 0;
            int newID=0;
            for (int i = 1; i < tour.station.Count-1; ++i)
            {
                newID = i;
                for(int j = 1; j < tour.station.Count - 1; ++j)
                {
                    if (i == j)
                    {
                        continue;
                    }
                    else
                    {
                        tour.Swap(i, j);
                        newDist = tour.TourLength();
                        if (newDist < minDist)
                        {
                            newID = j;
                        }

                        tour.Swap(j, i);
                    }
                    
                }
                if (newID != i)
                {
                    tour.Swap(i, newID);
                }
            }
            return tour;
        }
        //LEVEL 3 - ######################################################################################################################################################
        public static Tour ExhaustiveSearch(Tour tour)
        {
            //Tour ans = tour;
            //foreach (Station s in tour.station)
            //{
            //    if (s.Equals(stations[0]))
            //    {
            //        ans.station.Remove(s);
            //        break;
            //    }
            //}
            //ans.station.Remove(stations[0]);
            tour.station.Add(stations[0]);
            //ans.station.Insert(0, stations[0]);
            //float min = tour.TourLength();
            //Generate(tour, k-1);
            return Generate(tour, tour.station.Count-2);
        }

        //public static Tour Generate(int k, float min, Tour t, Tour ans)
        //{ 
        //    if (k == 2)
        //    {
        //        if (t.TourLength() < min)
        //        {
        //            ans = t;
        //        }
        //    }
        //    else
        //    {
        //        // Generate permutations with kth unaltered
        //        // Initially k == length(A)
        //        Generate(k - 1, min, t, ans);

        //        // Generate permutations for kth swapped with each k-1 initial
        //        for (int i = 1; i < k - 1; i += 1)
        //        {
        //            // Swap choice dependent on parity of k (even or odd)
        //            if (k % 2 == 0)
        //            {
        //                t.Swap(i, k-1); // zero-indexed, the kth is at k-1
        //            }
        //            else
        //            {
        //                t.Swap(1, k-1);
        //            }
        //            Generate(k - 1, min, t, ans);


        //        }
        //    }
        //    return ans;
        //}

        public static Tour Generate(Tour ans, int n)
        {
            //c is an encoding of the stack state. c[k] encodes the for-loop counter for when generate(k+1, A) is called
            int[] c = new int[n];
            Tour newAns = ans;

            for (int k = 0; k < n; k++)
            {
                c[k] = 1;
            }

            //output(A)

            //i acts similarly to the stack pointer
            int i = 1;
            while (i < n)
            {
                if (c[i] < i)
                {
                    if (i % 2 == 0)
                    {
                        //  swap(A[0], A[i]);
                        ans.Swap(1, i);
                    }
                    else
                    {
                        //swap(A[c[i]], A[i]);
                        ans.Swap(c[i], i);
                    }

                    // output(A)
                    if (ans.TourLength() < newAns.TourLength())
                    {
                        newAns = ans;
                    }
                    //Swap has occurred ending the for-loop. Simulate the increment of the for-loop counter
                    c[i] += 1;
                    //Simulate recursive call reaching the base case by bringing the pointer to the base case analog in the array
                    i = 1;
                }
                else
                {
                    //Calling generate(i+1, A) has ended as the for-loop terminated. Reset the state and simulate popping the stack by incrementing the pointer.
                    c[i] = 1;
                    i += 1;
                }

            }
            return newAns;
        }
    }

}